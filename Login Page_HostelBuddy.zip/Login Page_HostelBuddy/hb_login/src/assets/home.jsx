import React from 'react';
import '../assets/Home.css'; 
import logo from '../assets/hb_logo.png';

function Home() {
  return (
    <div className="home-container">
      <h1 className="home-title">Hello! Welcome to HostelBuddy!</h1>
      <h2 className="home-subtitle">Site under progress!</h2>
      <div className="home-description">
        <p>We are planning to develop a portal application called HostelBuddy to address various hostel-related issues. The features we aim to include are:</p>
        <ul>
          <li>
            <strong>Roommate Matchmaking Framework:</strong> This feature is especially useful for first-year students, as they often struggle to find compatible roommates initially. Through an MCQ-based form, students can select their traits and preferences, enabling the system to match them with individuals of similar personalities or interests.
          </li>
          <li>
            <strong>Lost-and-Found Portal:</strong> If someone loses an item, they can post about it here. This feature will bridge the gap in communication across different years and branches, ensuring important information reaches everyone effectively.
          </li>
          <li>
            <strong>Buy/Sell Portal for Notes and Supplies:</strong> A dedicated platform where students can buy or sell academic materials such as notes, lab coats, or drafting tools. This feature will be particularly beneficial for inter-year use, connecting those looking to sell items with those who need them but otherwise wouldn't know who to contact.
          </li>
        </ul>
      </div>
    </div>
  );
}

export default Home;
// import React from 'react';
// import './Home.css';
// import logo from '../assets/hb_logo.png'; // Adjust the path as necessary

// const Home = () => {
//   return (
//     <div className="home-container">
//       <header className="header">
//         <div className="logo-container">
//           <img src={logo} alt="HostelBuddy Logo" className="logo" />
//           <span className="brand-name">HostelBuddy</span>
//         </div>
//         <nav className="nav">
//           <a href="#about">About</a>
//           <a href="#matchmaking">Roommate Finder</a>
//           <a href="#lost-found">Lost & Found</a>
//           <a href="#buy-sell">Buy/Sell</a>
//           <a href="#contact">Contact Us</a>
//         </nav>
//       </header>
//       <main className="main-content">
//         <div className="intro">
//           <h1>Confused about who matches your vibes?</h1>
//           <p>Find someone you would love to share your room with through our Roommate Finder!</p>
//           <button className="btn-primary" onClick={() => window.location.href='#matchmaking'}>Find a Roommate</button>
//         </div>
//         <div className="intro-image">
//           <img src={logo} alt="HostelBuddy Logo" />
//         </div>
//       </main>
//       <section id="features" className="features">
//         <div className="feature">
//           <h2>Roommate Matchmaking Framework</h2>
//           <p>This feature is especially useful for first-year students, as they often struggle to find compatible roommates initially. Through an MCQ-based form, students can select their traits and preferences, enabling the system to match them with individuals of similar personalities or interests.</p>
//         </div>
//         <div className="feature">
//           <h2>Lost-and-Found Portal</h2>
//           <p>If someone loses an item, they can post about it here. This feature will bridge the gap in communication across different years and branches, ensuring important information reaches everyone effectively.</p>
//         </div>
//         <div className="feature">
//           <h2>Buy/Sell Portal for Notes and Supplies</h2>
//           <p>A dedicated platform where students can buy or sell academic materials such as notes, lab coats, or drafting tools. This feature will be particularly beneficial for inter-year use, connecting those looking to sell items with those who need them but otherwise wouldn't know who to contact.</p>
//         </div>
//       </section>
//       <footer className="footer">
//         <div className="footer-logo">HostelBuddy</div>
//         <p>&copy; 2024 HostelBuddy. All rights reserved.</p>
//       </footer>
//     </div>
//   );
// }

// export default Home;
